"use client";

import { createClient } from "@/lib/supabase/client";
import { FaGithub } from "react-icons/fa";
import { Button } from "@/components/ui/button";

export function OAuthButtons() {
  const supabase = createClient();

  async function handleOAuth(provider: "github" | "google") {
    const origin = typeof window !== "undefined" ? window.location.origin : "";

    await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${origin}/auth/callback`,
        // GitHub needs the "repo" scope here, not just in the separate
        // connect-github-prompt flow: a solver who signs UP through GitHub
        // never passes through that prompt, and without this their stored
        // token can't read their private repos — so mirroring a private
        // submission would 404 at clone time. Google ignores scopes.
        ...(provider === "github" ? { scopes: "repo" } : {}),
        queryParams: {
          prompt: "select_account", // Forces Google to show the account picker every time
        },
      },
    });
  }

  return (
    <div className="flex flex-col gap-2.5">
      {/* GitHub Button */}
      <Button
        type="button"
        variant="outline"
        onClick={() => handleOAuth("github")}
        className="w-full justify-center gap-2 border-border bg-surface text-foreground hover:bg-surface-raised hover:text-foreground"
      >
        <FaGithub size={16} />
        Continue with GitHub
      </Button>

      {/* Google Button */}
      <Button
        type="button"
        variant="outline"
        onClick={() => handleOAuth("google")}
        className="w-full justify-center gap-2 border-border bg-surface text-foreground hover:bg-surface-raised hover:text-foreground"
      >
        <svg width="16" height="16" viewBox="0 0 24 24">
          <path
            fill="#4285F4"
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
          />
          <path
            fill="#34A853"
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
          />
          <path
            fill="#FBBC05"
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
          />
          <path
            fill="#EA4335"
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
          />
        </svg>
        Continue with Google
      </Button>
    </div>
  );
}